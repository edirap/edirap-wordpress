<?php
$timestamp = 1336373380;
$auto_import = 1;

?>